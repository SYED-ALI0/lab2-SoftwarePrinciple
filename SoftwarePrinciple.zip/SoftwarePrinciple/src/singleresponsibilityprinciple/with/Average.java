package singleresponsibilityprinciple.with;

import java.util.Scanner;

public class Average {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num1 = getInput("first", scanner);
        double num2 = getInput("second", scanner);
        double num3 = getInput("third", scanner);

        double average = calculateAverage(num1, num2, num3);

        displayResult(num1, num2, num3, average);

        scanner.close();
    }

    public static double getInput(String order, Scanner scanner) {
        System.out.print("Enter the " + order + " number: ");
        return scanner.nextDouble();
    }

    public static double calculateAverage(double num1, double num2, double num3) {
        return (num1 + num2 + num3) / 3;
    }

    public static void displayResult(double num1, double num2, double num3, double average) {
        System.out.println("The average of " + num1 + ", " + num2 + ", and " + num3 + " is: " + average);
    }
}
